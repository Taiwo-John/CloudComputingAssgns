<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>  

<?php
$bknameError = $authorError = $qtyError = "";
$bookname = $author = $qty = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["bookname"])) {
    $bknameError = "Book Name is required";
  } else {
    $bookname = record_input($_POST["bookname"]);
    if (!preg_match("/^[a-zA-Z ]*$/",$bookname)) {
      $bknameError = "Only letters and white space allowed";
    }
  }
  
  if (empty($_POST["author"])) {
    $authorError = "Author name is required";
  } else {
    $author = record_input($_POST["author"]);
    if (!preg_match("/^[a-zA-Z ]*$/",$author)) {
      $authorError = "Only letters and white space allowed";
    }
  }

  if (empty($_POST["qty"])) {
    $qtyError = "Quantity is required";
  } else {
    $qty = record_input($_POST["qty"]);
  }
}

function record_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<h3>Simple Book Record Form</h3>
<p><span class="error">* required field</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  Book Name: <input type="text" name="bookname" value="<?php echo $bookname;?>">
  <span class="error">* <?php echo $bknameError;?></span>
  <br><br>
  Author: <input type="text" name="author" value="<?php echo $author;?>">
  <span class="error">* <?php echo $authorError;?></span>
  <br><br>
  Quantity: <input type="text" name="qty" value="<?php echo $qty;?>">
  <span class="error">* <?php echo $qtyError;?></span>
  <br><br>
  <input type="submit" name="submit" value="Submit">  
</form>

<?php
echo "<h3>You have entered the following:</h3>";
echo $bookname;
echo "<br>";
echo $author;
echo "<br>";
echo $qty;
echo "<br>";
?>